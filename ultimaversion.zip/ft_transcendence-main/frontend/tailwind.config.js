/** @type {import('tailwindcss').Config} */
module.exports = {
	content: [
		"./public/**/*.html",
		"./src/**/*.ts",
	],
	theme: {
		extend: {},
	},
	plugins: [],
};